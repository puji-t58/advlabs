// main.js

function convertWeightFromKg() {
    let kg = parseFloat(document.getElementById("kgInput").value);
    if (!isNaN(kg)) {
        document.getElementById("lbInput").value = (kg * 2.20462).toFixed(2);
    }
}

function convertWeightFromLb() {
    let lb = parseFloat(document.getElementById("lbInput").value);
    if (!isNaN(lb)) {
        document.getElementById("kgInput").value = (lb / 2.20462).toFixed(2);
    }
}

function convertDistanceFromKm() {
    let km = parseFloat(document.getElementById("kmInput").value);
    if (!isNaN(km)) {
        document.getElementById("mileInput").value = (km * 0.621371).toFixed(2);
    }
}

function convertDistanceFromMiles() {
    let miles = parseFloat(document.getElementById("mileInput").value);
    if (!isNaN(miles)) {
        document.getElementById("kmInput").value = (miles / 0.621371).toFixed(2);
    }
}

function convertTemperatureFromCelsius() {
    let celsius = parseFloat(document.getElementById("celsiusInput").value);
    if (!isNaN(celsius)) {
        document.getElementById("fahrenheitInput").value = ((celsius * 9/5) + 32).toFixed(2);
    }
}

function convertTemperatureFromFahrenheit() {
    let fahrenheit = parseFloat(document.getElementById("fahrenheitInput").value);
    if (!isNaN(fahrenheit)) {
        document.getElementById("celsiusInput").value = ((fahrenheit - 32) * 5/9).toFixed(2);
    }
}

// Scientific Calculator Functions
function appendCharacter(character) {
    document.getElementById("calc-display").value += character;
}

function performOperation(operation) {
    document.getElementById("calc-display").value += operation;
}

function clearDisplay() {
    document.getElementById("calc-display").value = "";
}

function deleteCharacter() {
    let display = document.getElementById("calc-display");
    display.value = display.value.slice(0, -1);
}

function calculateResult() {
    let display = document.getElementById("calc-display");
    try {
        display.value = eval(display.value);
    } catch (e) {
        display.value = "Error";
    }
}

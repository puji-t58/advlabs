import React, { useState } from 'react';
import './App.css';

function App() {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState('');
  const [isEditing, setIsEditing] = useState(null);
  const [currentTask, setCurrentTask] = useState('');
  const [newPriority, setNewPriority] = useState('Medium');
  const [filter, setFilter] = useState('All');

  const addTask = () => {
    if (newTask.trim()) {
      setTasks([...tasks, { text: newTask, isCompleted: false, priority: newPriority }]);
      setNewTask('');
      setNewPriority('Medium');
    }
  };

  const deleteTask = (index) => {
    const newTasks = tasks.filter((_, i) => i !== index);
    setTasks(newTasks);
  };

  const editTask = (index) => {
    setIsEditing(index);
    setCurrentTask(tasks[index].text);
  };

  const saveTask = (index) => {
    const newTasks = tasks.map((task, i) =>
      i === index ? { ...task, text: currentTask } : task
    );
    setTasks(newTasks);
    setIsEditing(null);
    setCurrentTask('');
  };

  const toggleCompletion = (index) => {
    const newTasks = tasks.map((task, i) =>
      i === index ? { ...task, isCompleted: !task.isCompleted } : task
    );
    setTasks(newTasks);
  };

  const filteredTasks = tasks.filter(task => {
    if (filter === 'All') return true;
    if (filter === 'Completed') return task.isCompleted;
    if (filter === 'Incomplete') return !task.isCompleted;
    return false;
  });

  return (
    <div className="App">
      <header className="header">
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTy1eDovRF0hLYHH1QG9iakiuxcmINKCIklew&s" alt="Logo" className="logo" />
        <h1>To-Do List</h1>
      </header>
      <div className="content">
        <div className="input-container">
          <input
            type="text"
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            placeholder="Enter new task"
          />
          <select value={newPriority} onChange={(e) => setNewPriority(e.target.value)}>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
          <button onClick={addTask}>Add Task</button>
        </div>
        <div className="filter-container">
          <button onClick={() => setFilter('All')}>All</button>
          <button onClick={() => setFilter('Completed')}>Completed</button>
          <button onClick={() => setFilter('Incomplete')}>Incomplete</button>
        </div>
        <ul>
          {filteredTasks.map((task, index) => (
            <li key={index}>
              {isEditing === index ? (
                <>
                  <input
                    type="text"
                    value={currentTask}
                    onChange={(e) => setCurrentTask(e.target.value)}
                  />
                  <button onClick={() => saveTask(index)}>Save</button>
                </>
              ) : (
                <>
                  <span
                    onClick={() => toggleCompletion(index)}
                    style={{
                      textDecoration: task.isCompleted ? 'line-through' : 'none',
                      color: task.priority === 'High' ? 'red' : task.priority === 'Medium' ? 'orange' : 'green',
                    }}
                  >
                    {task.text}
                  </span>
                  <button onClick={() => editTask(index)}>Edit</button>
                  <button onClick={() => deleteTask(index)}>Delete</button>
                </>
              )}
            </li>
          ))}
        </ul>
      </div>
      <footer className="footer">
        <p>© 2024 Pujitha Tallapally. Contact: 1234 University Blvd, Birmingham, AL 35294</p>
      </footer>
    </div>
  );
}

export default App;
